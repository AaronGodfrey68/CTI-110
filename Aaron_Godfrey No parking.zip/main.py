print('  NO PARKING')
print('2:00 - 6:00 a.m.')
