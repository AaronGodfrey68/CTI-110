userNum = int(input())
userNumSquar = userNum*userNum   # Bug here; fix it when instructed
   
print(userNumSquar)       # Output formatting issue here; fix it when instructed